# Parking API Spring Boot 프로젝트

## 실행 방법

1. JDK 17 이상 설치되어 있어야 합니다.
2. Gradle로 실행:

   ./gradlew bootRun     (Unix/Mac)
   gradlew.bat bootRun   (Windows)

또는 jar로 빌드 후 실행:

   ./gradlew build
   java -jar build/libs/parking-api-complete-0.0.1-SNAPSHOT.jar

## 설명
- 메인 클래스: com.example.parking.ParkingApiApplication
- 광주광역시 공공데이터 API에서 주차장 정보를 가져와 반환합니다.
- 외부 API 호출이 포함되어 있으므로 인터넷 연결이 필요합니다.


## 서비스 키 설정 방법

`src/main/resources/application.properties` 파일에서 다음 항목을 수정하세요:

    service.key=발급받은_공공데이터_API_키

(예: https://www.data.go.kr 에서 발급)